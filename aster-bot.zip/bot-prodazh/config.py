# Токен бота
MAIN_BOT_TOKEN = '7789558007:AAERiRJiXPd136D8SXElbF48xGKtLtGpkFU'  # Замените на токен вашего бота

# ID администраторов и менеджеров
ADMIN_IDS = [7335347499,7072685825,542540985,1135787694]      # Замените на реальные ID администраторов
MANAGER_IDS = [7335347499,7072685825,542540985,1135787694]    # Замените на реальные ID менеджеров
# MySQL Database Configuration
DB_HOST = 'localhost'
DB_PORT = 3306
DB_USER = 'root'
DB_PASSWORD = 'Biznes2019'
DB_NAME = 'zakbot'